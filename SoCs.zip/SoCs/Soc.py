import json
import random
import os
import tkinter as tk
from tkinter import messagebox
from datetime import datetime

INTERVAL_MS = 180 * 1000  # 3 dakika, test için 2000 ms yapabilirsin

JSON_FILES = ["1.json", "2.json", "3.json", "4.json"]
TRUE_FILE = "analyst_true.json"
FALSE_FILE = "analyst_false.json"

SEVERITY_COLORS = {
    "low": "#2ecc71",
    "medium": "#f1c40f",
    "high": "#e74c3c"
}

COUNTRIES = {
    "USA": "🇺🇸",
    "Russia": "🇷🇺",
    "China": "🇨🇳",
    "Germany": "🇩🇪",
    "France": "🇫🇷",
    "UK": "🇬🇧",
    "India": "🇮🇳"
}


class SOCSimulator:
    def __init__(self, root):
        self.root = root
        self.root.title("🛡️ Elastic SOC Simulation")
        self.root.geometry("1300x750")

        self.events = []
        self.queue = []
        self.current_event = None
        self.displayed_event = None  # sadece sağ panel için
        self.snoozed = []

        self.stats = {
            "TRUE": 0,
            "FALSE": 0,
            "SNOOZE": 0,
            "low": 0,
            "medium": 0,
            "high": 0
        }

        self.listbox_event_map = {}  # Listbox ile event eşlemesi

        self.load_all_events()
        self.build_ui()
        self.root.after(1000, self.next_event)  # otomatik event başlat

    def load_all_events(self):
        for file in JSON_FILES:
            if os.path.exists(file):
                with open(file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    for event in data:
                        event.setdefault("severity", random.choice(list(SEVERITY_COLORS)))
                        event.setdefault("country", random.choice(list(COUNTRIES)))
                        event.setdefault("id", random.randint(1000, 9999))
                        event["_handled"] = False
                        self.events.append(event)
        self.queue = self.events.copy()

    def build_ui(self):
        header = tk.Label(self.root, text="🛡️ ELASTIC SOC – LIVE INCIDENT FEED",
                          font=("Arial", 22, "bold"))
        header.pack(pady=10)

        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        # Sol panel
        self.listbox = tk.Listbox(self.main_frame, width=55)
        self.listbox.pack(side=tk.LEFT, fill=tk.Y, padx=10)
        self.listbox.bind("<<ListboxSelect>>", self.show_selected_event)

        # Sağ panel
        self.right = tk.Frame(self.main_frame)
        self.right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.alert_label = tk.Label(self.right, font=("Arial", 16, "bold"))
        self.alert_label.pack(pady=5)

        self.text = tk.Text(self.right, height=20)
        self.text.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        btns = tk.Frame(self.right)
        btns.pack(pady=5)

        self.true_btn = tk.Button(btns, text="✅ TRUE", width=15,
                                  command=lambda: self.mark_event("TRUE"))
        self.false_btn = tk.Button(btns, text="❌ FALSE", width=15,
                                   command=lambda: self.mark_event("FALSE"))
        self.snooze_btn = tk.Button(btns, text="⏸️ SNOOZE", width=15,
                                    command=self.snooze_event)

        self.true_btn.pack(side=tk.LEFT, padx=5)
        self.false_btn.pack(side=tk.LEFT, padx=5)
        self.snooze_btn.pack(side=tk.LEFT, padx=5)

        self.dashboard = tk.LabelFrame(self.root, text="📊 SOC Dashboard", font=("Arial", 12, "bold"))
        self.dashboard.pack(fill=tk.X, padx=10, pady=5)

        self.dashboard_label = tk.Label(self.dashboard, font=("Arial", 12))
        self.dashboard_label.pack()

        self.update_dashboard()

    def update_dashboard(self):
        self.dashboard_label.config(
            text=f"TRUE: {self.stats['TRUE']} | FALSE: {self.stats['FALSE']} | "
                 f"SNOOZE: {self.stats['SNOOZE']} || "
                 f"🟢 Low: {self.stats['low']} 🟡 Medium: {self.stats['medium']} 🔴 High: {self.stats['high']}"
        )

    def next_event(self):
        # Eğer queue boşsa, snoozed tekrar eklenir
        if not self.queue and not self.snoozed:
            self.finish_soc()
            return
        if not self.queue:
            self.queue = self.snoozed.copy()
            self.snoozed.clear()

        # otomatik sıradaki event
        self.current_event = self.queue.pop(0)
        self.display_event(event=self.current_event, add_to_listbox=True)
        self.root.after(INTERVAL_MS, self.next_event)

    def display_event(self, event, add_to_listbox=False):
        # Sağ panelde gösterim
        self.displayed_event = event
        color = SEVERITY_COLORS[event["severity"]]
        flag = COUNTRIES[event["country"]]

        self.alert_label.config(
            text=f"ALERT {event['id']} | {event['severity'].upper()} | {flag} {event['country']}",
            bg=color
        )

        self.text.delete("1.0", tk.END)
        for k, v in event.items():
            if not k.startswith("_"):
                self.text.insert(tk.END, f"{k}: {v}\n")

        # Listbox’a ekle sadece yeni event ise
        if add_to_listbox:
            display_text = f"ID {event['id']} | {event['severity'].upper()} | {flag}"
            self.listbox.insert(tk.END, display_text)
            self.listbox_event_map[display_text] = event
            # severity istatistiklerini sadece yeni event için arttır
            self.stats[event["severity"]] += 1
            self.update_dashboard()

    def mark_event(self, decision):
        if not self.displayed_event:
            return
        event = self.displayed_event
        event["_handled"] = True
        self.stats[decision] += 1
        self.save_decision(event, decision)
        self.update_dashboard()

        # Listbox’tan kaldır
        for i in range(self.listbox.size()):
            text = self.listbox.get(i)
            if self.listbox_event_map.get(text) == event:
                self.listbox.delete(i)
                break

        # Eğer snoozed içindeyse kaldır
        if event in self.snoozed:
            self.snoozed.remove(event)

    def snooze_event(self):
        if not self.displayed_event:
            return
        event = self.displayed_event
        self.stats["SNOOZE"] += 1
        if event not in self.snoozed:
            self.snoozed.append(event)
        self.update_dashboard()

    def save_decision(self, event, decision):
        file = TRUE_FILE if decision == "TRUE" else FALSE_FILE
        record = event.copy()
        record["decision"] = decision
        record["time"] = datetime.utcnow().isoformat() + "Z"

        data = []
        if os.path.exists(file):
            data = json.load(open(file, encoding="utf-8"))
        data.append(record)
        json.dump(data, open(file, "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    def show_selected_event(self, _):
        i = self.listbox.curselection()
        if i:
            display_text = self.listbox.get(i)
            event = self.listbox_event_map[display_text]
            self.display_event(event)  # sadece sağ panelde göster, timer etkilenmez

    def finish_soc(self):
        unhandled = [e for e in self.events if not e["_handled"]]
        if unhandled:
            messagebox.showwarning(
                "SOC",
                f"{len(unhandled)} olay işaretlenmedi!\nTRUE / FALSE kararlarını tamamla."
            )
            return

        if messagebox.askyesno("SOC", "Analiz tamamlandı. Raporu gönderdin mi?"):
            self.root.quit()


if __name__ == "__main__":
    root = tk.Tk()
    SOCSimulator(root)
    root.mainloop()

